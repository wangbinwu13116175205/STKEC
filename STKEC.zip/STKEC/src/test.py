import sys, json, argparse, random, re, os, shutil
#sys.path.append("src/")
from re import S
import torch
import numpy as np
from torch import nn
from torch.autograd import grad 
from torch_geometric.data import DataLoader
from torch.utils.data import DataLoader as DataLoaders
from torch_geometric.utils import to_dense_batch, k_hop_subgraph
from time import time
import torch.nn.functional as func

import os.path as osp

from trafficDataset import TrafficDataset
from model.model import Basic_Model
from INfluence.inverse_hvp2 import get_inverse_hvps2
#from utils.my_math import masked_mae_np, masked_mape_np, masked_mse_np
import sys
sys.path.append("..")
from utils import common_tools as ct
#from src.utils import common_tools as ct
import networkx as nx
os.environ['CUDA_VISIBLE_DEVICES'] = '0,3'
def generate_samples(days, savepath, data, graph, train_rate=0.6, val_rate=0.2, test_rate=0.2, val_test_mix=False):
    edge_index = np.array(list(graph.edges)).T
    del graph
    data = data[0:days*288, :]
    t, n = data.shape[0], data.shape[1]
   
    train_idx = [i for i in range(int(t*train_rate))]
    val_idx = [i for i in range(int(t*train_rate), int(t*(train_rate+val_rate)))]
    test_idx = [i for i in range(int(t*(train_rate+val_rate)), t)]
    
    train_x, train_y = generate_dataset(data, train_idx)
    val_x, val_y = generate_dataset(data, val_idx)
    test_x, test_y = generate_dataset(data, test_idx)
    if val_test_mix:
        val_test_x = np.concatenate((val_x, test_x), 0)
        val_test_y = np.concatenate((val_y, test_y), 0)
        val_test_idx = np.arange(val_x.shape[0]+test_x.shape[0])
        np.random.shuffle(val_test_idx)
        val_x, val_y = val_test_x[val_test_idx[:int(t*val_rate)]], val_test_y[val_test_idx[:int(t*val_rate)]]
        test_x, test_y = val_test_x[val_test_idx[int(t*val_rate):]], val_test_y[val_test_idx[int(t*val_rate):]]

    train_x = z_score(train_x)
    val_x = z_score(val_x)
    test_x = z_score(test_x)
    np.savez(savepath, train_x=train_x, train_y=train_y, val_x=val_x, val_y=val_y, test_x=test_x, test_y=test_y, edge_index=edge_index)
    data = {"train_x":train_x, "train_y":train_y, "val_x":val_x, "val_y":val_y, "test_x":test_x, "test_y":test_y, "edge_index":edge_index}
    return data
def update(src, tmp):
    for key in tmp:
        if key!= "gpuid":
            src[key] = tmp[key]
def init(args):    
    conf_path = 'conf/trafficStream.json'
    info = ct.load_json_file(conf_path)
    #info["time"] = datetime.now().strftime("%Y-%m-%d-%H:%M:%S.%f")
    update(vars(args), info)
    #vars(args)["path"] = osp.join(args.model_path, args.logname+args.time)
    ct.mkdirs(args.path)
    del info

class DictObj(object):
    def __init__(self,map):
        self.map = map

    def __setattr__(self, name, value):
        if name == 'map':
             object.__setattr__(self, name, value)
             return
        #print 'set attr called ',name,value
        self.map[name] = value

    def __getattr__(self,name):
        v = self.map[name]
        if isinstance(v,(dict)):
            return DictObj(v)
        if isinstance(v, (list)):
            r = []
            for i in v:
                r.append(DictObj(i))
            return r                      
        else:
            return self.map[name]

    def __getitem__(self,name):
        return self.map[name]

def sav_s_test(model,    subgraph,
                          inputs,
                          preproc_fn,adj1,
                          approx_type='lissa',
                          lissa_params='LISSA_PARAMS',
                          verbose=True):
    model.eval()
    adj1=adj1.to(device)
    model=model.to(device)
    params = list(model.parameters())
    criterion = func.mse_loss
    train_data=TrafficDataset("", "", x=inputs["train_x"][-288*1-1:, :,:], y=inputs["train_y"][-288*1-1:, :, :],edge_index="", mode="subgraph")
    test_dataset=TrafficDataset("", "", x=inputs["val_x"][-288*1-1:, :,:], y=inputs["val_y"][-288*1-1:, :,:],edge_index="", mode="subgraph")
    test_loader = DataLoader(test_dataset, batch_size=128, shuffle=False)
    s_test_values = []
    for s_test_idx, data in enumerate(test_loader):
        data = data.to(device)
        loss = criterion(model(data,adj1), data.y)
        test_grads = grad(loss, params)
        s_test = get_inverse_hvps2(model, criterion, train_data, test_grads,device,adj1,lissa_params)
        s_test_values.append(s_test)


path='/home/wbw/ijcai3/ijcai2/ijcai2/res/district3F11T17/trafficStream2021-12-23-14:29:09.054946/2011/16.2959.pkl'
conf_path = '../conf/trafficStream.json'
arg = ct.load_json_file(conf_path)
args=DictObj(arg)
#init(args)
#init_log(args)
#device = torch.device("cuda:{}".format(args.gpuid)) if torch.cuda.is_available()  else "cpu"
device="cpu"
vars(args)['device']=device
model = Basic_Model(args)
model.load_state_dict(torch.load(path)["model_state_dict"])

year=2011
graph = nx.from_numpy_matrix(np.load(osp.join(args.graph_path, str(year)+"_adj.npz"))["x"])
vars(args)["graph_size"] = graph.number_of_nodes()
vars(args)["year"] = year
inputs = generate_samples(30, osp.join(args.save_data_path, str(year)+'_30day'), np.load(osp.join(args.raw_data_path, str(year)+".npz"))["x"], graph, val_test_mix=True) \
            if args.data_process else np.load(osp.join(args.save_data_path, str(year)+"_30day.npz"), allow_pickle=True)
adj = np.load(osp.join(args.graph_path, str(args.year)+"_adj.npz"))["x"]
adj = adj / (np.sum(adj, 1, keepdims=True) + 1e-6)
vars(args)["adj"] = torch.from_numpy(adj).to(torch.float)
vars(args)["mapping"] = ''
cur_graph = torch.LongTensor(np.array(list(nx.from_numpy_matrix(np.load(osp.join(args.graph_path, str(year)+"_adj.npz"))["x"]).edges)).T)
edge_list = list(nx.from_numpy_matrix(np.load(osp.join(args.graph_path, str(year)+"_adj.npz"))["x"]).edges)
graph_node_from_edge = set()
for (u,v) in edge_list:
    graph_node_from_edge.add(u)
    graph_node_from_edge.add(v)
node_list = list(graph_node_from_edge)
subgraph, subgraph_edge_index, mapping, _ = k_hop_subgraph(node_list, num_hops=args.num_hops, edge_index=cur_graph, relabel_nodes=True)
vars(args)["sub_adj"] = vars(args)["adj"]
LISSA_PARAMS = {
    "batch_size": 1,
    "num_repeats": 10,
    "recursion_depth": 500,
    "scale":1,
}
lossf=func.mse_loss
sav_s_test(model,subgraph, inputs,lossf,args.adj,'lissa',LISSA_PARAMS)