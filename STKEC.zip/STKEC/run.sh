#!/bin/bash
python STKEC.py --conf STKEC.json --gpuid 1

